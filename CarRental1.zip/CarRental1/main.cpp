#include <QApplication>
#include <QMainWindow>
#include <QTabWidget>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QMessageBox>
#include <QGroupBox>
#include <QHeaderView>
#include <QRandomGenerator>
#include <QDateEdit>
#include <QComboBox>
#include <QDialog>
#include <QDebug>
#include <QStackedWidget>
#include <QPixmap>
#include <QString> // QString sınıfı için
#include <QDoubleSpinBox> // Yeni: Fiyat girişi için
#include <QFormLayout> // Yeni: Form düzeni için

#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <stdexcept>
using namespace std;

/* ===================== SINIFLAR VE KALITIM HİYERARŞİLERİ ===================== */

class Branch;
class NotificationSystem {
public:
    void sendNotification(const string& username, const string& message) {
        cout << "NOTIFICATION sent to " << username << ": " << message << endl;
    }
};

class Employee { // ABSTRACT
protected:
    string username;
    string password;
    string name;
public:
    Employee(string u, string p, string n) : username(u), password(p), name(n) {}
    virtual ~Employee() {}
    virtual string getRole() = 0;
    string getUsername() const { return username; }
    string getPassword() const { return password; }
    string getName() const { return name; }
};

class Manager : public Employee {
public:
    Manager(string u, string p, string n) : Employee(u, p, n) {}
    string getRole() override { return "Manager"; }
};

class Sales : public Employee {
public:
    Sales(string u, string p, string n) : Employee(u, p, n) {}
    string getRole() override { return "Sales"; }
};

class Customer {
public:
    string name, phone;
    int id;
    string username;
    string password;
    int totalRentals;

    Customer(string n, string p, int i, string u, string pass)
        : name(n), phone(p), id(i), username(u), password(pass), totalRentals(0) {}
    string getUsername() const { return username; }
    string getPassword() const { return password; }
    string getName() const { return name; }
};


class Branch {
public:
    int id;
    string name;
    string address;
    Manager* manager;

    Branch(int i, string n, string a, Manager* m) : id(i), name(n), address(a), manager(m) {}
};


class Vehicle { // ABSTRACT
protected:
    string plate, model, brand;
    double pricePerDay;
    string status;
    Branch* branch;
public:
    // Yapıcı (Constructor)
    Vehicle(string p, string m, string b, double pr, Branch* br)
        : plate(p), model(m), brand(b), pricePerDay(pr), status("Available"), branch(br) {}

    // Sanal Yıkıcı (Virtual Destructor)
    virtual ~Vehicle() {}

    // Saf Sanal Fonksiyon (Pure Virtual Function)
    virtual double calculatePrice(int d) = 0;
    virtual string getType() = 0;

    // --- Getter Fonksiyonları ---
    string getPlate() const { return plate; }
    string getModel() const { return model; }
    string getBrand() const { return brand; }
    double getPricePerDay() const { return pricePerDay; }
    string getStatus() const { return status; }

    // --- Setter Fonksiyonları ---

    // Fiyatı ayarlayan setter (Önceki hata çözümü için kritik)
    void setPricePerDay(double newPrice) {
        pricePerDay = newPrice;
    }

    // Durumu ayarlayan setter (Mevcut kodunuzda da kullanılıyor)
    void setStatus(string s) {
        status = s;
    }
};

class EconomyCar : public Vehicle {
public:
    EconomyCar(string p, string m, string b, Branch* br) : Vehicle(p, m, b, 500.0, br) {}
    double calculatePrice(int d) override { return d * pricePerDay; }
    string getType() override { return "Economy"; }
};

class LuxuryCar : public Vehicle {
public:
    LuxuryCar(string p, string m, string b, Branch* br) : Vehicle(p, m, b, 1200.0, br) {}
    double calculatePrice(int d) override { return d * pricePerDay; }
    string getType() override { return "Luxury"; }
};


class Insurance { // ABSTRACT
protected:
    double dailyCost;
public:
    Insurance(double cost) : dailyCost(cost) {}
    virtual ~Insurance() {}
    virtual string getName() = 0;
    double getDailyCost() const { return dailyCost; }
};

class BasicInsurance : public Insurance {
public:
    BasicInsurance() : Insurance(50.0) {}
    string getName() override { return "Basic"; }
};

class PremiumInsurance : public Insurance {
public:
    PremiumInsurance() : Insurance(150.0) {}
    string getName() override { return "Premium"; }
};


class Rental {
public:
    int id;
    Customer* customer;
    Vehicle* vehicle;
    int days;
    double price;
    string startDate;
    string endDate;
    string status;
    Insurance* insurance;

    Rental(int rentalId, Customer* c, Vehicle* v, int d, string sDate, Insurance* ins) {
        id = rentalId;
        customer = c;
        vehicle = v;
        days = d;
        insurance = ins;
        price = v->calculatePrice(d) + (ins->getDailyCost() * d);
        startDate = sDate;
        endDate = "N/A";
        status = "Active";
        c->totalRentals++;
    }
};

class MaintenanceRecord {
public:
    int id;
    Vehicle* vehicle;
    string type;
    string description;
    double cost;
    string date;

    MaintenanceRecord(int mid, Vehicle* v, string t, string desc, double c, string d)
        : id(mid), vehicle(v), type(t), description(desc), cost(c), date(d) {
        v->setStatus("Maintenance");
    }
};

class Payment {
protected:
    double amount;
    string date;
    int rentalId; // YENİ: Rental ID alanı
public:
    // Yapıcıyı 3 parametre alacak şekilde güncelleyin
    Payment(double a, string d, int rId) : amount(a), date(d), rentalId(rId) {}

    virtual ~Payment() {}

    // Alt sınıfların uygulamasını zorunlu kılmak için saf sanal (pure virtual)
    virtual string getType() = 0;

    // Getter'lar
    int getRentalId() const { return rentalId; }
    double getAmount() const { return amount; } // getAmount eklendi (image_01cd72.png hatasını çözer)
    string getDate() const { return date; }     // getDate eklendi (image_01cd72.png hatasını çözer)
};

class CashPayment : public Payment {
public:
    // Yapıcıyı 3 parametre alacak şekilde güncelleyin (amount, date, rentalId)
    CashPayment(double a, string d, int rId)
        : Payment(a, d, rId) {}

    string getType() override { return "Cash"; } // Doğru override
};

class CardPayment : public Payment {
private:
    string cardNumber;
public:
    // Yapıcıyı 4 parametre alacak şekilde güncelleyin (amount, date, cardNumber, rentalId)
    CardPayment(double a, string d, string cn, int rId)
        : Payment(a, d, rId), cardNumber(cn) {}

    string getType() override { return "Card"; } // Doğru override
};
class OnlinePayment : public Payment {
public:
    // Online ödeme olduğu için kart numarası zorunlu değil, 3 parametre yeterli.
    OnlinePayment(double a, string d, int rId)
        : Payment(a, d, rId) {}

    string getType() override { return "Online Transfer"; }
};


/* ===================== GLOBAL VERİ VE YARDIMCI FONKSİYONLAR ===================== */

vector<Employee*> employees;
vector<Branch*> branches;
vector<Insurance*> insuranceOptions;
vector<Customer*> customers;
vector<Vehicle*> vehicles;
vector<Rental*> rentals;
vector<Payment*> payments;
vector<MaintenanceRecord*> maintenanceRecords;

NotificationSystem notificationSystem;

Employee* findEmployeeByUsername(const std::string& username);
Vehicle* findVehicle(const string& plate);



Rental* findRentalById(int id) {
    auto it = find_if(rentals.begin(), rentals.end(),
                      [&](Rental* r){ return r->id == id; });
    return (it != rentals.end()) ? *it : nullptr;
}

// YENİ YARDIMCI FONKSİYON: Şube Ekleme Diyaloğu

void createAddBranchDialog(const std::function<void()>& updateFunc) {
    QDialog dialog;
    dialog.setWindowTitle("Yeni Şube Ekle");
    dialog.setFixedSize(400, 300);



    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);
    QFormLayout *formLayout = new QFormLayout();

    // Form Elemanları
    QLineEdit *nameInput = new QLineEdit();
    QLineEdit *addressInput = new QLineEdit();
    QLineEdit *phoneInput = new QLineEdit();
    QComboBox *managerCombo = new QComboBox();

    // Sadece Manager rolündeki çalışanları Combo Box'a ekle
    std::vector<Employee*> availableManagers;
    for (Employee* emp : employees) {
        if (emp->getRole() == "Manager") {
            // Şube Müdürü atanmamış olanları bulmak biraz daha karmaşık.
            // Basitlik adına tüm Manager'ları listeliyoruz.
            managerCombo->addItem(QString::fromStdString(emp->getName()) + " (" + QString::fromStdString(emp->getUsername()) + ")");
            availableManagers.push_back(emp);
        }
    }

    if (managerCombo->count() == 0) {
        QMessageBox::warning(&dialog, "Hata", "Sistemde atanabilir yönetici bulunmamaktadır.");
        dialog.reject();
        return;
    }

    formLayout->addRow("Şube Adı:", nameInput);
    formLayout->addRow("Adres:", addressInput);
    formLayout->addRow("Telefon:", phoneInput);
    formLayout->addRow("Şube Müdürü:", managerCombo);

    mainLayout->addLayout(formLayout);

    // Butonlar
    QPushButton *saveBtn = new QPushButton("Şubeyi Kaydet");
    QPushButton *cancelBtn = new QPushButton("İptal");
    saveBtn->setStyleSheet("background-color: #007BFF; color: white;");

    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnLayout->addWidget(saveBtn);
    btnLayout->addWidget(cancelBtn);
    mainLayout->addLayout(btnLayout);

    QObject::connect(cancelBtn, &QPushButton::clicked, &dialog, &QDialog::reject);

    // Kaydetme İşlemi
    QObject::connect(saveBtn, &QPushButton::clicked, [&, updateFunc]() {
        QString name = nameInput->text();
        QString address = addressInput->text();
        QString phone = phoneInput->text();

        if (name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            QMessageBox::warning(&dialog, "Hata", "Tüm alanlar boş bırakılamaz.");
            return;
        }

        // Seçilen Yöneticinin Username'ini al
        QString selectedManagerText = managerCombo->currentText();
        QString managerUsername = selectedManagerText.section('(', 1, 1).section(')', 0, 0);

        Employee* manager = findEmployeeByUsername(managerUsername.toStdString());

        if (!manager || manager->getRole() != "Manager") {
            QMessageBox::critical(&dialog, "Hata", "Seçilen yönetici bilgisi geçersiz.");
            return;
        }

        // Yeni ID oluştur
        int newBranchId = branches.empty() ? 1 : branches.back()->id + 1;

        // Yeni Şube Nesnesini Oluşturma ve Ekleme
        Branch* newBranch = new Branch(newBranchId, name.toStdString(), address.toStdString(), static_cast<Manager*>(manager));
        branches.push_back(newBranch);

        QMessageBox::information(&dialog, "Başarılı", QString("Yeni Şube ('%1') başarıyla eklendi.").arg(name));

        // KRİTİK: Tüm tabloları (özellikle Araç Ekleme formlarında şube listesinin güncellenmesi için) güncelle
        updateFunc();

        dialog.accept();
    });

    dialog.exec();
}


// Yeni: Bakım Kaydı Ekleme Diyaloğu

void createAddMaintenanceDialog(QTableWidget* maintenanceTable, const std::vector<Vehicle*>& vehicles,
                                const std::function<void()>& updateMaintenanceTable,
                                const std::function<void()>& updateVehicleTable,
                                const std::function<void()>& updateAllTablesFunc,// KRİTİK: Bu parametreyi ekle
                                NotificationSystem& notificationSystem) {
    QDialog dialog;
    dialog.setWindowTitle("Yeni Bakım Kaydı Ekle");
    dialog.setFixedSize(450, 350);

    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);

    // Form Elemanları
    QComboBox *vehicleCombo = new QComboBox();
    for (Vehicle* v : vehicles) {
        if (v->getStatus() != "Maintenance") { // Bakımda olmayanları listele
            vehicleCombo->addItem(QString::fromStdString(v->getPlate()) + " - " + QString::fromStdString(v->getModel()));
        }
    }

    // Eğer araç yoksa uyarı ver
    if (vehicleCombo->count() == 0) {
        QMessageBox::information(&dialog, "Bilgi", "Bakıma alınabilecek uygun araç bulunmamaktadır.");
        dialog.reject();
        return;
    }

    QLineEdit *typeInput = new QLineEdit();
    typeInput->setPlaceholderText("Örn: Yağ Değişimi, Lastik Değişimi");
    QLineEdit *descriptionInput = new QLineEdit();
    descriptionInput->setPlaceholderText("Açıklama");
    QDoubleSpinBox *costInput = new QDoubleSpinBox();
    costInput->setRange(0.0, 50000.0);
    costInput->setSuffix(" TL");
    QDateEdit *dateEdit = new QDateEdit(QDate::currentDate());
    dateEdit->setDisplayFormat("dd/MM/yyyy");

    // Layout'a Ekleme
    QGroupBox *formGroup = new QGroupBox("Bakım Bilgileri");
    QFormLayout *formLayout = new QFormLayout(formGroup);
    formLayout->addRow("Araç (Plaka - Model):", vehicleCombo);
    formLayout->addRow("Bakım Tipi:", typeInput);
    formLayout->addRow("Açıklama:", descriptionInput);
    formLayout->addRow("Maliyet:", costInput);
    formLayout->addRow("Tarih:", dateEdit);

    // Butonlar
    QPushButton *saveBtn = new QPushButton("Kaydı Oluştur");
    QPushButton *cancelBtn = new QPushButton("İptal");
    saveBtn->setStyleSheet("background-color: #A9A9A9; color: black;");

    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnLayout->addWidget(saveBtn);
    btnLayout->addWidget(cancelBtn);

    mainLayout->addWidget(formGroup);
    mainLayout->addLayout(btnLayout);


    // SİNYAL BAĞLANTILARI
    QObject::connect(cancelBtn, &QPushButton::clicked, &dialog, &QDialog::reject);
    QObject::connect(saveBtn, &QPushButton::clicked, [&, updateAllTablesFunc]() {
        QString selectedVehicleText = vehicleCombo->currentText();
        QString plate = selectedVehicleText.split(" - ").at(0); // Plakayı al
        QString type = typeInput->text();
        QString description = descriptionInput->text();
        double cost = costInput->value();
        string date = dateEdit->date().toString("dd/MM/yyyy").toStdString();

        if (type.isEmpty() || description.isEmpty()) {
            QMessageBox::warning(&dialog, "Hata", "Bakım Tipi ve Açıklama alanları boş bırakılamaz.");
            return;
        }

        Vehicle* vehicleToMaintain = findVehicle(plate.toStdString());

        if (!vehicleToMaintain) {
            QMessageBox::critical(&dialog, "Hata", "Seçilen araç sistemde bulunamadı.");
            return;
        }

        // Bakım Kaydı Nesnesini Oluşturma
        int newMaintenanceId = maintenanceRecords.empty() ? 1 : maintenanceRecords.back()->id + 1;

        // ÖNEMLİ: MaintenanceRecord yapıcı içinde aracın durumu otomatik olarak "Maintenance" olur.
        MaintenanceRecord* newRecord = new MaintenanceRecord(
            newMaintenanceId,
            vehicleToMaintain,
            type.toStdString(),
            description.toStdString(),
            cost,
            date
            );

        maintenanceRecords.push_back(newRecord);
        updateMaintenanceTable(); // Bakım tablosunu güncelle
        updateVehicleTable();     // Araç durumları değiştiği için araç tablosunu da güncelle

        notificationSystem.sendNotification(
            "Manager",
            "Vehicle " + plate.toStdString() + " is now in maintenance (" + type.toStdString() + ")."
            );

        QMessageBox::information(&dialog, "Başarılı", QString("'%1' plakalı araç için bakım kaydı başarıyla oluşturuldu.").arg(plate));
        updateAllTablesFunc(); // <<< YENİ ÇAĞRI
        dialog.accept();
    });

    dialog.exec();
}

// GÜNCELLENDİ: Araç modeline göre resim dosya yolunu döndürür (Tüm uzantılar artık .jpg)
QString getVehicleImagePath(const string& model) {
    string m = model;
    transform(m.begin(), m.end(), m.begin(), ::tolower);

    // Kodu :images/ kullanarak güncelledim. Eğer bu çalışmazsa, başındaki :/ işaretini silin.
    if (m == "clio") return "images/clio.jpg";
    if (m == "520i") return "images/bmw520i.jpg";
    if (m == "egea") return "images/egea.jpg";
    // Hoş geldiniz görseli için özel bir durum ekleyelim.
    if (m == "welcome") return "images/welcome.jpg";
    return "images/default_car.jpg";
}

Vehicle* findVehicle(const string& plate) {
    auto it = find_if(vehicles.begin(), vehicles.end(),
                      [&](Vehicle* v){ return v->getPlate() == plate; });
    return (it != vehicles.end()) ? *it : nullptr;
}

Customer* findCustomerByUsername(const string& username) {
    auto it = find_if(customers.begin(), customers.end(),
                      [&](Customer* c){ return c->username == username; });
    return (it != customers.end()) ? *it : nullptr;
}

Employee* findEmployeeByUsername(const string& username) {
    auto it = find_if(employees.begin(), employees.end(),
                      [&](Employee* e){ return e->getUsername() == username; });
    return (it != employees.end()) ? *it : nullptr;
}

void updateCustomerPanelTable(QTableWidget* table) {
    if (!table) return;
    table->setRowCount(0);
    table->setColumnCount(5); // 5 sütun: Görsel, Model, Tip, Fiyat, Plaka
    table->setHorizontalHeaderLabels({"Görsel", "Model", "Tip", "Günlük Fiyat", "Plaka"});
    table->setColumnWidth(0, 100); // Görsel sütun genişliği

    for (Vehicle* v : vehicles) {
        if (v->getStatus() == "Available") {
            int row = table->rowCount();
            table->insertRow(row);
            table->setRowHeight(row, 80); // Resim için satır yüksekliğini artır

            // 1. GÖRSELİ EKLEME
            QLabel *imageLabel = new QLabel();
            QPixmap pixmap(getVehicleImagePath(v->getModel()));
            // Hata kontrolü ve ölçekleme
            if (!pixmap.isNull()) {
                imageLabel->setPixmap(pixmap.scaled(100, 80, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            } else {
                imageLabel->setText("No Image");
            }
            imageLabel->setAlignment(Qt::AlignCenter);
            table->setCellWidget(row, 0, imageLabel);

            // Diğer sütunlar 1'den başlar
            table->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(v->getModel())));
            table->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(v->getType())));
            table->setItem(row, 3, new QTableWidgetItem(QString::number(v->getPricePerDay(), 'f', 2) + " TL"));
            table->setItem(row, 4, new QTableWidgetItem(QString::fromStdString(v->getPlate())));
        }
    }
}

// Yeni araç ekleme diyalogunu oluşturan yardımcı fonksiyon
void createAddVehicleDialog(QTableWidget* vehicleTable, const std::vector<Branch*>& branches,
                            const std::function<void()>& updateVehicleTable, NotificationSystem& notificationSystem) {
    QDialog dialog;
    dialog.setWindowTitle("Yeni Araç Ekle");
    dialog.setFixedSize(400, 300);

    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);

    // Form Elemanları
    QLineEdit *plateInput = new QLineEdit();
    QLineEdit *brandInput = new QLineEdit();
    QLineEdit *modelInput = new QLineEdit();
    QDoubleSpinBox *priceInput = new QDoubleSpinBox(); // DoubleSpinBox daha uygun
    priceInput->setRange(100.0, 5000.0);
    priceInput->setValue(600.0);
    priceInput->setSuffix(" TL");
    QComboBox *typeCombo = new QComboBox();
    typeCombo->addItem("Economy");
    typeCombo->addItem("Luxury");

    // Layout'a Ekleme
    QGroupBox *formGroup = new QGroupBox("Araç Bilgileri");
    QFormLayout *formLayout = new QFormLayout(formGroup);
    formLayout->addRow("Plaka:", plateInput);
    formLayout->addRow("Marka:", brandInput);
    formLayout->addRow("Model:", modelInput);
    formLayout->addRow("Günlük Fiyat:", priceInput); // Sadece Manager'lar için fiyat girişi ekleyelim
    formLayout->addRow("Tip:", typeCombo);

    // Butonlar
    QPushButton *saveBtn = new QPushButton("Aracı Kaydet");
    QPushButton *cancelBtn = new QPushButton("İptal");
    saveBtn->setStyleSheet("background-color: #28a745; color: white;");

    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnLayout->addWidget(saveBtn);
    btnLayout->addWidget(cancelBtn);

    mainLayout->addWidget(formGroup);
    mainLayout->addLayout(btnLayout);


    // SİNYAL BAĞLANTILARI
    QObject::connect(cancelBtn, &QPushButton::clicked, &dialog, &QDialog::reject);
    QObject::connect(saveBtn, &QPushButton::clicked, [&]() {
        QString plate = plateInput->text().toUpper();
        QString brand = brandInput->text();
        QString model = modelInput->text();
        double price = priceInput->value();
        QString type = typeCombo->currentText();

        if (plate.isEmpty() || brand.isEmpty() || model.isEmpty()) {
            QMessageBox::warning(&dialog, "Hata", "Plaka, Marka ve Model alanları boş bırakılamaz.");
            return;
        }

        if (findVehicle(plate.toStdString())) {
            QMessageBox::warning(&dialog, "Hata", "Bu plakaya sahip bir araç zaten sistemde kayıtlı.");
            return;
        }

        // Basit Fiyat Kontrolü (Type'a göre fiyatı ayarlayalım)
        if (type == "Economy" && price < 400) price = 500.0;
        else if (type == "Luxury" && price < 1000) price = 1200.0;

        // Araç Nesnesini Oluşturma (İlk şubeye atayalım)
        Vehicle* newVehicle = nullptr;
        Branch* defaultBranch = branches.empty() ? nullptr : branches[0];

        if (!defaultBranch) {
            QMessageBox::critical(&dialog, "Hata", "Sistemde kayıtlı bir şube bulunamadı. Araç eklenemiyor.");
            return;
        }

        // SADECE NESNEYİ OLUŞTURUYORUZ, FİYAT ATAMASINI SONRA YAPACAĞIZ.
        if (type == "Economy") {
            newVehicle = new EconomyCar(plate.toStdString(), model.toStdString(), brand.toStdString(), defaultBranch);
        } else if (type == "Luxury") {
            newVehicle = new LuxuryCar(plate.toStdString(), model.toStdString(), brand.toStdString(), defaultBranch);
        }


        if (newVehicle) {
            // BU TEK SATIR YETERLİDİR ve HATA VERMEZ.
            newVehicle->setPricePerDay(price);

            vehicles.push_back(newVehicle);
            updateVehicleTable(); // Tabloyu güncelle
            notificationSystem.sendNotification("Manager", "New vehicle " + newVehicle->getPlate() + " added to the fleet.");
            QMessageBox::information(&dialog, "Başarılı", QString("'%1' plakalı araç başarıyla eklendi.").arg(plate));
            dialog.accept();
        } else {
            QMessageBox::critical(&dialog, "Hata", "Araç nesnesi oluşturulamadı.");
        }
    });

    dialog.exec();
}
/* ===================== MAIN ===================== */

int main(int argc, char *argv[]) {

    QApplication app(argc, argv);

    // Ana pencere ve yığılmış widget
    QMainWindow mainWindow;
    QStackedWidget *stackedWidget = new QStackedWidget;
    mainWindow.setCentralWidget(stackedWidget);
    mainWindow.setWindowTitle("🚗 Kiralama Yönetim Sistemi");
    mainWindow.resize(1100, 700);

    // --- BAŞLANGIÇ VERİSİ ---
    Manager* m1 = new Manager("manager", "123", "Alice Manager");
    Sales* s1 = new Sales("sales", "123", "Bob Sales");
    employees.push_back(m1);
    employees.push_back(s1);

    customers.push_back(new Customer("Test Müşteri", "5551112233", 1001, "customer1", "123"));

    Branch* b1 = new Branch(1, "Main Branch", "Ankara, Turkey", m1);
    branches.push_back(b1);

    insuranceOptions.push_back(new BasicInsurance());
    insuranceOptions.push_back(new PremiumInsurance());

    vehicles.push_back(new EconomyCar("34ABC11", "Clio", "Renault", b1));
    vehicles.push_back(new LuxuryCar("06XYZ99", "520i", "BMW", b1));
    vehicles.push_back(new EconomyCar("16DEF22", "Egea", "Fiat", b1));

    /* ===================== BİLEŞEN TANIMLARI ===================== */

    // ORTAK: Giriş/Kayıt Alanları
    QLineEdit *login_usernameInput = new QLineEdit();
    QLineEdit *login_passwordInput = new QLineEdit();
    login_passwordInput->setEchoMode(QLineEdit::Password);


    // ORTAK: Kayıt Alanları
    QLineEdit *register_nameInput = new QLineEdit();
    QLineEdit *register_phoneInput = new QLineEdit();
    QLineEdit *register_usernameInput = new QLineEdit();
    QLineEdit *register_passwordInput = new QLineEdit();
    register_passwordInput->setEchoMode(QLineEdit::Password);

    // YÖNETİM PANELİ
    QTabWidget *adminTabs = new QTabWidget();
    QTableWidget *vehicleTable = new QTableWidget(0, 7); // 7 sütun: Görsel + 6 veri
    QTableWidget *customerTable = new QTableWidget(0, 5);
    QTableWidget *rentalTable = new QTableWidget(0, 7);
    QTableWidget *paymentTable = new QTableWidget(0, 4);
    QTableWidget *maintenanceTable = new QTableWidget(0, 5);
    QPushButton *addVehicleBtn = new QPushButton("+ Add Vehicle");
    QPushButton *recordPaymentBtn = new QPushButton("Record New Payment");
    QPushButton *addMaintenanceBtn = new QPushButton("Add Maintenance Record");
    QPushButton *addBranchBtn = new QPushButton("Add New Branch");
    QTableWidget *branchTable = new QTableWidget();
    QTableWidget *employeeTable = new QTableWidget(0, 5); // <<< BU SATIRI EKLEYİN


    //********
    // Branch Tab (Layout)
    // Branch Tab (Layout)
    QWidget *branchesTab = new QWidget();
    QVBoxLayout *branchesLayout = new QVBoxLayout(branchesTab);

    QLabel *branchInfoLabel = new QLabel("<h3>🏢 Mevcut Şubeler</h3>");
    branchesLayout->addWidget(branchInfoLabel);

    // Tabloyu ekle
    branchTable->setColumnCount(4);
    branchTable->setHorizontalHeaderLabels({"ID", "Şube Adı", "Adres", "Müdür (Kullanıcı Adı)"});
    branchTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch); // Şube Adı genişlesin

    branchesLayout->addWidget(branchTable);
    branchesLayout->addWidget(addBranchBtn);
    //********

    // MÜŞTERİ PANELİ
    QTableWidget *customerVehicleTable = new QTableWidget(0, 5); // 5 sütun
    QLineEdit *rentDaysInput = new QLineEdit();
    QDateEdit *startDateEdit = new QDateEdit(QDate::currentDate());
    QComboBox *insuranceCombo = new QComboBox();
    QPushButton *rentCarBtn = new QPushButton("Seçili Aracı Kirala");


    // --- Tablo Güncelleme Lambda Fonksiyonları ---

    auto updateVehicleTable = [&]() {
        vehicleTable->setRowCount(0);
        vehicleTable->setColumnWidth(0, 100); // Görsel sütun genişliği
        vehicleTable->setHorizontalHeaderLabels({"Görsel", "Brand", "Model", "Type", "Plate", "Daily Rate", "Status"});

        for(Vehicle* v : vehicles) {
            int row = vehicleTable->rowCount();
            vehicleTable->insertRow(row);
            vehicleTable->setRowHeight(row, 80); // Resim için satır yüksekliğini artır

            // 1. GÖRSELİ EKLEME
            QLabel *imageLabel = new QLabel();
            QPixmap pixmap(getVehicleImagePath(v->getModel()));
            if (!pixmap.isNull()) {
                imageLabel->setPixmap(pixmap.scaled(100, 80, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            } else {
                imageLabel->setText("No Image");
            }
            imageLabel->setAlignment(Qt::AlignCenter);
            vehicleTable->setCellWidget(row, 0, imageLabel); // 0. sütuna görseli ekle

            // Diğer sütunlar 1'den başlar
            vehicleTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(v->getBrand())));
            vehicleTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(v->getModel())));
            vehicleTable->setItem(row, 3, new QTableWidgetItem(QString::fromStdString(v->getType())));
            vehicleTable->setItem(row, 4, new QTableWidgetItem(QString::fromStdString(v->getPlate())));
            vehicleTable->setItem(row, 5, new QTableWidgetItem(QString::number(v->getPricePerDay(), 'f', 2) + " / day"));
            vehicleTable->setItem(row, 6, new QTableWidgetItem(QString::fromStdString(v->getStatus())));
        }
        updateCustomerPanelTable(customerVehicleTable);
    };

    auto updateCustomerTable = [&]() {
        customerTable->setRowCount(0);
        for(Customer* c : customers) {
            int row = customerTable->rowCount();
            customerTable->insertRow(row);
            customerTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(c->name)));
            customerTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(c->username)));
            customerTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(c->phone)));
            customerTable->setItem(row, 3, new QTableWidgetItem(QString::number(c->id)));
            customerTable->setItem(row, 4, new QTableWidgetItem(QString::number(c->totalRentals)));
        }
    };

    auto updateRentalTable = [&]() {
        rentalTable->setRowCount(0);
        for(Rental* r : rentals) {
            int row = rentalTable->rowCount();
            rentalTable->insertRow(row);

            // Önceki sütunları doldurma
            rentalTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(r->customer->getName())));
            rentalTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(r->vehicle->getModel())));
            rentalTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(r->startDate)));
            rentalTable->setItem(row, 3, new QTableWidgetItem(QString::fromStdString(r->endDate)));
            rentalTable->setItem(row, 4, new QTableWidgetItem(QString::number(r->price, 'f', 2) + " TL"));
            rentalTable->setItem(row, 5, new QTableWidgetItem(QString::fromStdString(r->status)));

            // Eylemler sütununu (6. sütun) oluşturma
            QWidget *actionWidget = new QWidget();
            QHBoxLayout *actionLayout = new QHBoxLayout(actionWidget);
            QPushButton *endRentalBtn = new QPushButton("End/Complete");

            // KRİTİK: Rental ID'sini butona Object Name olarak atayın
            endRentalBtn->setObjectName(QString::number(r->id));

            actionLayout->addWidget(endRentalBtn);
            actionLayout->setAlignment(Qt::AlignCenter);
            actionLayout->setContentsMargins(0, 0, 0, 0);

            rentalTable->setCellWidget(row, 6, actionWidget);
        }
    };

    auto updatePaymentTable = [&]() {
        paymentTable->setRowCount(0);
        // ...
        for(Payment* p : payments) {
            int row = paymentTable->rowCount();
            paymentTable->insertRow(row);

            // [0]: Rental ID
            paymentTable->setItem(row, 0, new QTableWidgetItem(QString::number(p->getRentalId()))); // DÜZELTİLDİ: Rental ID eklendi

            // [1]: Amount (Miktar)
            // Hatalı Eski: p->getType() -> Yeni: p->getAmount()
            paymentTable->setItem(row, 1, new QTableWidgetItem(QString::number(p->getAmount(), 'f', 2) + " TL")); // DÜZELTİLDİ

            // [2]: Method (Tip)
            // Hatalı Eski: p->getMethod() -> Yeni: p->getType()
            paymentTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(p->getType()))); // DÜZELTİLDİ

            // [3]: Date
            paymentTable->setItem(row, 3, new QTableWidgetItem(QString::fromStdString(p->getDate())));
        }
    };

    auto updateMaintenanceTable = [&]() {
        maintenanceTable->setRowCount(0);
        for(MaintenanceRecord* m : maintenanceRecords) {
            int row = maintenanceTable->rowCount();
            maintenanceTable->insertRow(row);
            maintenanceTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(m->vehicle->getPlate())));
            maintenanceTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(m->type)));
            maintenanceTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(m->description)));
            maintenanceTable->setItem(row, 3, new QTableWidgetItem(QString::number(m->cost, 'f', 2)));
            maintenanceTable->setItem(row, 4, new QTableWidgetItem(QString::fromStdString(m->date)));
        }
    };

    // --- Branch Tablosunu Güncelleme Fonksiyonu ---
    auto updateBranchTable = [&]() {
        branchTable->setRowCount(0);

        for (Branch* b : branches) {
            int row = branchTable->rowCount();
            branchTable->insertRow(row);

            // [0]: ID
            branchTable->setItem(row, 0, new QTableWidgetItem(QString::number(b->id)));

            // [1]: Şube Adı
            branchTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(b->name)));

            // [2]: Adres
            branchTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(b->address)));

            // [3]: Müdür (Username)
            // Manager sınıfının Employee sınıfından türediğini varsayarak username alıyoruz.
            QString managerUsername = QString::fromStdString(b->manager->getUsername());
            branchTable->setItem(row, 3, new QTableWidgetItem(managerUsername));
        }
    };

    auto updateEmployeeTable = [&]() {
        // employeeTable'ın tanımını göremedim, bu yüzden 5 sütunlu standart bir yapı kullanacağım:
        // Employee* sınıfının getUsername(), getName(), getRole() metodlarına sahip olduğunu varsayarız.
        // Eğer çalışan tablosunu oluşturmadıysanız, main'in başında bunu da eklemelisiniz.
        // QTableWidget *employeeTable = new QTableWidget(0, 5);

        employeeTable->setRowCount(0);
        employeeTable->setHorizontalHeaderLabels({"Kullanıcı Adı", "Ad Soyad", "Pozisyon", "Şube ID", "Total Rentals"});
        employeeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

        for (Employee* e : employees) {
            int row = employeeTable->rowCount();
            employeeTable->insertRow(row);

            // [0] Kullanıcı Adı
            employeeTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(e->getUsername())));
            // [1] Ad Soyad (Employee sınıfında getName() veya benzeri bir metot olduğunu varsayarız)
            employeeTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(e->getName())));
            // [2] Pozisyon (Role)
            employeeTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(e->getRole())));
            // [3] Şube ID (Eğer Employee sınıfında getBranchId() veya benzeri bir metot varsa ekleyin)
            // Şimdilik boş bırakıyorum veya 'N/A' yazıyorum.
            employeeTable->setItem(row, 3, new QTableWidgetItem("N/A"));
            // [4] Toplam İşlem Sayısı (Eğer Employee sınıfında böyle bir özellik varsa)
            employeeTable->setItem(row, 4, new QTableWidgetItem("N/A"));
        }
    };

    auto updateAllTables = [&]() {
        updateVehicleTable();
        updateCustomerTable();
        updateEmployeeTable(); // <<< ARTIK BURADA HATA VERMEYECEK
        updateMaintenanceTable();
        updatePaymentTable();
        updateBranchTable();
        // Diğer tüm update...Table() lambdalarını buraya ekleyin.
    };



    /* ===================== LAYOUT KURULUMU ===================== */

    // 0. WELCOME SCREEN (Hoş Geldiniz Ekranı)
    QWidget *welcomePage = new QWidget;
    QVBoxLayout *welcomeLayout = new QVBoxLayout(welcomePage);

    // GÜNCELLENDİ: Başlık daha görünür ve stilize edildi
    QLabel *welcomeLabel = new QLabel("<h2>🚗 Araç Kiralama Sistemine Hoş Geldiniz!</h2>");
    welcomeLabel->setAlignment(Qt::AlignCenter);
    welcomeLabel->setStyleSheet(
        "QLabel {"
        "   background-color: rgba(255, 255, 255, 0.95);" // Hafif şeffaf beyaz arka plan
        "   color: #333333;" // Koyu metin rengi
        "   border: 1px solid #CCCCCC;"
        "   border-radius: 10px;"
        "   padding: 15px;" // Yazının etrafına boşluk ekle
        "}"
        );

    // GÜNCELLENDİ: Görsel daha büyük
    QLabel *welcomeImage = new QLabel();
    QPixmap welcomePixmap(getVehicleImagePath("welcome")); // Artık .jpg kullanacak

    if (!welcomePixmap.isNull()) {
        // Boyutu 600x350 olarak güncelliyoruz
        welcomeImage->setPixmap(welcomePixmap.scaled(600, 350, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        welcomeImage->setAlignment(Qt::AlignCenter);
    } else {
        welcomeImage->setText("Görsel Yüklenemedi: images/welcome.jpg");
        welcomeImage->setAlignment(Qt::AlignCenter);
    }

    QPushButton *welcome_loginBtn = new QPushButton("Giriş Yap");
    QPushButton *welcome_registerBtn = new QPushButton("Kayıt Ol");
    welcome_loginBtn->setFixedSize(150, 40);
    welcome_registerBtn->setFixedSize(150, 40);

    // GÜNCELLENDİ: Butonlar stilize edildi
    welcome_loginBtn->setStyleSheet("background-color: #4CAF50; color: white; border-radius: 5px; padding: 10px;");
    welcome_registerBtn->setStyleSheet("background-color: #007BFF; color: white; border-radius: 5px; padding: 10px;");


    QHBoxLayout *welcomeButtonLayout = new QHBoxLayout;
    welcomeButtonLayout->addStretch(1);
    welcomeButtonLayout->addWidget(welcome_loginBtn);
    welcomeButtonLayout->addWidget(welcome_registerBtn);
    welcomeButtonLayout->addStretch(1);

    // GÜNCELLENDİ: Layout düzeni (Boşluklar eklendi)
    welcomeLayout->addStretch(1);
    welcomeLayout->addWidget(welcomeLabel);
    welcomeLayout->addSpacing(20); // Başlık ile görsel arasına boşluk
    welcomeLayout->addWidget(welcomeImage);
    welcomeLayout->addSpacing(20); // Görsel ile butonlar arasına boşluk
    welcomeLayout->addLayout(welcomeButtonLayout);
    welcomeLayout->addStretch(1);

    // GÜNCELLENDİ: Arka plan rengi eklendi
    welcomePage->setStyleSheet("background-color: #F8F8F8;");

    stackedWidget->addWidget(welcomePage); // Index 0

    // 1. LOGIN SCREEN (Giriş Yap Ekranı)
    QWidget *loginPage = new QWidget;
    QVBoxLayout *loginLayout = new QVBoxLayout(loginPage);

    QLabel *loginTitle = new QLabel("<h2>👤 Kullanıcı Girişi</h2>");
    loginTitle->setAlignment(Qt::AlignCenter);

    QPushButton *backToWelcomeBtn_L = new QPushButton("<- Geri");
    backToWelcomeBtn_L->setFixedSize(100, 30);
    QHBoxLayout *loginHeader = new QHBoxLayout;
    loginHeader->addWidget(backToWelcomeBtn_L);
    loginHeader->addStretch(1);
    loginHeader->addWidget(loginTitle);
    loginHeader->addStretch(1);

    QPushButton *loginBtn = new QPushButton("Giriş Yap");

    loginLayout->addLayout(loginHeader);
    loginLayout->addStretch(1);
    loginLayout->addWidget(new QLabel("Kullanıcı Adı:"));
    loginLayout->addWidget(login_usernameInput);
    loginLayout->addWidget(new QLabel("Şifre:"));
    loginLayout->addWidget(login_passwordInput);
    loginLayout->addWidget(loginBtn);
    loginLayout->addStretch(1);

    stackedWidget->addWidget(loginPage); // Index 1

    // 2. REGISTER SCREEN (Kayıt Ol Ekranı) - Sadece Müşteri
    QWidget *registerPage = new QWidget;
    QVBoxLayout *registerLayout = new QVBoxLayout(registerPage);

    QLabel *registerTitle = new QLabel("<h2>📝 Yeni Müşteri Kaydı</h2>");
    registerTitle->setAlignment(Qt::AlignCenter);

    QPushButton *backToWelcomeBtn_R = new QPushButton("<- Geri");
    backToWelcomeBtn_R->setFixedSize(100, 30);
    QHBoxLayout *registerHeader = new QHBoxLayout;
    registerHeader->addWidget(backToWelcomeBtn_R);
    registerHeader->addStretch(1);
    registerHeader->addWidget(registerTitle);
    registerHeader->addStretch(1);

    QPushButton *registerBtn = new QPushButton("Kayıt Ol (Müşteri)");

    registerLayout->addLayout(registerHeader);
    registerLayout->addStretch(1);
    registerLayout->addWidget(new QLabel("Ad Soyad:"));
    registerLayout->addWidget(register_nameInput);
    registerLayout->addWidget(new QLabel("Telefon:"));
    registerLayout->addWidget(register_phoneInput);
    registerLayout->addWidget(new QLabel("Kullanıcı Adı:"));
    registerLayout->addWidget(register_usernameInput);
    registerLayout->addWidget(new QLabel("Şifre:"));
    registerLayout->addWidget(register_passwordInput);
    registerLayout->addWidget(registerBtn);
    registerLayout->addStretch(1);

    stackedWidget->addWidget(registerPage); // Index 2

    // 3. YÖNETİM PANELİ (Admin Panel)
    QWidget *adminPage = new QWidget;
    QVBoxLayout *adminLayout = new QVBoxLayout(adminPage);

    QPushButton *adminLogoutBtn = new QPushButton("Çıkış Yap");
    adminLogoutBtn->setFixedSize(100, 30);

    QHBoxLayout *adminHeaderLayout = new QHBoxLayout;
    adminHeaderLayout->addStretch(1);
    adminHeaderLayout->addWidget(adminLogoutBtn);

    // Vehicles Tab (Layout)
    QWidget *vehiclesTab = new QWidget();
    vehicleTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    QHBoxLayout *vTopLayout = new QHBoxLayout();
    vTopLayout->addWidget(new QLabel("VEHICLE MANAGEMENT"));
    vTopLayout->addStretch(1);
    vTopLayout->addWidget(addVehicleBtn);
    QVBoxLayout *vehiclesLayout = new QVBoxLayout(vehiclesTab);
    vehiclesLayout->addLayout(vTopLayout);
    vehiclesLayout->addWidget(vehicleTable);

    // Customers Tab (Layout)
    QWidget *customersTab = new QWidget();
    customerTable->setHorizontalHeaderLabels({"Full Name", "Username", "Phone", "ID", "Total Rentals"});
    customerTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    QVBoxLayout *customersLayout = new QVBoxLayout(customersTab);
    customersLayout->addWidget(customerTable);

    // Rentals Tab (Layout)
    QWidget *rentalTab = new QWidget();
    rentalTable->setHorizontalHeaderLabels({"Customer", "Vehicle", "Start Date", "End Date", "Total Cost", "Status", "Actions"});
    rentalTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    QVBoxLayout *rentalLayout = new QVBoxLayout(rentalTab);
    rentalLayout->addWidget(rentalTable);

    // Payments Tab (Layout)
    QWidget *paymentsTab = new QWidget();
    paymentTable->setHorizontalHeaderLabels({"Rental ID", "Amount (TL)", "Method", "Date"});
    paymentTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    recordPaymentBtn->setStyleSheet("background-color: #008000; color: white;");
    QVBoxLayout *paymentsLayout = new QVBoxLayout(paymentsTab);
    paymentsLayout->addWidget(recordPaymentBtn);
    paymentsLayout->addWidget(paymentTable);

    // Maintenance Tab (Layout)
    QWidget *maintenanceTab = new QWidget();
    maintenanceTable->setHorizontalHeaderLabels({"Vehicle Plate", "Type", "Description", "Cost ($)", "Date"});
    maintenanceTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    addMaintenanceBtn->setStyleSheet("background-color: #A9A9A9; color: black;");
    QVBoxLayout *maintenanceLayout = new QVBoxLayout(maintenanceTab);
    maintenanceLayout->addWidget(addMaintenanceBtn);
    maintenanceLayout->addWidget(maintenanceTable);

    adminLayout->addLayout(adminHeaderLayout);
    adminLayout->addWidget(adminTabs);
    stackedWidget->addWidget(adminPage); // Index 3

    // 4. MÜŞTERİ PANELİ (Customer Panel)
    QWidget *customerPage = new QWidget;
    QVBoxLayout *customerPanelLayout = new QVBoxLayout(customerPage);

    QPushButton *customerLogoutBtn = new QPushButton("Çıkış Yap");
    customerLogoutBtn->setFixedSize(100, 30);

    QHBoxLayout *customerHeaderLayout = new QHBoxLayout;
    customerHeaderLayout->addStretch(1);
    customerHeaderLayout->addWidget(customerLogoutBtn);

    customerPanelLayout->addWidget(customerVehicleTable); // Tabloyu ekle

    QGroupBox *rentBox = new QGroupBox("Kiralamayı Tamamla");
    QVBoxLayout *rentLayout = new QVBoxLayout(rentBox);
    rentDaysInput->setPlaceholderText("Kaç Gün Kiralanacak?");
    startDateEdit->setDisplayFormat("dd/MM/yyyy");
    rentCarBtn->setStyleSheet("background-color: #008000; color: white;");

    for (Insurance* ins : insuranceOptions) {
        insuranceCombo->addItem(QString::fromStdString(ins->getName()) + " (" + QString::number(ins->getDailyCost()) + " TL/day)");
    }

    rentLayout->addWidget(new QLabel("Başlangıç Tarihi:"));
    rentLayout->addWidget(startDateEdit);
    rentLayout->addWidget(new QLabel("Sigorta Seçeneği:"));
    rentLayout->addWidget(insuranceCombo);
    rentLayout->addWidget(new QLabel("Kiralama Gün Sayısı:"));
    rentLayout->addWidget(rentDaysInput);
    rentLayout->addWidget(rentCarBtn);

    customerPanelLayout->addWidget(rentBox);

    QTabWidget *customerTabs = new QTabWidget();
    customerTabs->addTab(customerPage, "🛒 Araçları Görüntüle ve Kirala");

    QWidget *customerTabContainer = new QWidget;
    QVBoxLayout *customerContainerLayout = new QVBoxLayout(customerTabContainer);
    customerContainerLayout->addLayout(customerHeaderLayout);
    customerContainerLayout->addWidget(customerTabs);

    stackedWidget->addWidget(customerTabContainer); // Index 4

    /* ===================== BAĞLANTILAR ===================== */

    // --- Geçiş Bağlantıları ---
    QObject::connect(welcome_loginBtn, &QPushButton::clicked, [&]() {
        stackedWidget->setCurrentIndex(1); // Login'e geç
    });
    QObject::connect(welcome_registerBtn, &QPushButton::clicked, [&]() {
        // Kayıt formu alanlarını temizle
        register_usernameInput->clear();
        register_passwordInput->clear();
        register_nameInput->clear();
        register_phoneInput->clear();
        stackedWidget->setCurrentIndex(2); // Register'a geç
    });
    QObject::connect(backToWelcomeBtn_L, &QPushButton::clicked, [&]() {
        stackedWidget->setCurrentIndex(0); // Welcome'a geri
    });
    QObject::connect(backToWelcomeBtn_R, &QPushButton::clicked, [&]() {
        stackedWidget->setCurrentIndex(0); // Welcome'a geri
    });
    QObject::connect(adminLogoutBtn, &QPushButton::clicked, [&]() {
        stackedWidget->setCurrentIndex(0); // Çıkış yap -> Welcome
        login_usernameInput->clear();
        login_passwordInput->clear();
        rentDaysInput->clear();
    });
    QObject::connect(customerLogoutBtn, &QPushButton::clicked, [&]() {
        stackedWidget->setCurrentIndex(0); // Çıkış yap -> Welcome
        login_usernameInput->clear();
        login_passwordInput->clear();

        // YENİ EKLEME
        rentDaysInput->clear();

        // OPSİYONEL: Ayrıca diğer kiralama form alanlarını da temizleyebilirsiniz.
        startDateEdit->setDate(QDate::currentDate());
        insuranceCombo->setCurrentIndex(0);
    });
    // --- Araç Ekleme İşlemi (Manager Paneli) ---
    QObject::connect(addVehicleBtn, &QPushButton::clicked, [&]() {
        // Sadece yönetici rolü için butonu çalıştır
        string loggedInUser = login_usernameInput->text().toStdString();
        Employee* employee = findEmployeeByUsername(loggedInUser);

        if (employee && employee->getRole() == "Manager") {
            createAddVehicleDialog(vehicleTable, branches, updateVehicleTable, notificationSystem);
        } else {
            QMessageBox::warning(adminPage, "Yetki Hatası", "Sadece Yöneticiler araç ekleyebilir.");
        }
    });
    // --- Bakım Kaydı Ekleme İşlemi (Manager Paneli) ---
    QObject::connect(addMaintenanceBtn, &QPushButton::clicked, [&]() {
        // Sadece yönetici rolü için butonu çalıştır
        string loggedInUser = login_usernameInput->text().toStdString();
        Employee* employee = findEmployeeByUsername(loggedInUser);

        if (employee && employee->getRole() == "Manager") {
            createAddMaintenanceDialog(maintenanceTable, vehicles, updateMaintenanceTable, updateVehicleTable, updateAllTables,notificationSystem);

        } else {
            QMessageBox::warning(adminPage, "Yetki Hatası", "Sadece Yöneticiler bakım kaydı ekleyebilir.");
        }
    });

    // --- Şube Ekleme İşlemi (Manager Paneli) ---
    QObject::connect(addBranchBtn, &QPushButton::clicked, [&]() {
        // Sadece yönetici rolü için butonu çalıştır
        string loggedInUser = login_usernameInput->text().toStdString();
        Employee* employee = findEmployeeByUsername(loggedInUser);

        if (employee && employee->getRole() == "Manager") {
            // Tüm tabloları güncelleyen lambdayı createAddBranchDialog'a gönderiyoruz.
            // updateVehicleTable'ı doğrudan göndererek tüm tabloları dolaylı yoldan güncellemiş oluruz.
            createAddBranchDialog(updateAllTables);
        } else {
            QMessageBox::warning(adminPage, "Yetki Hatası", "Sadece Yöneticiler yeni şube ekleyebilir.");
        }
    });



    // --- Kayıt İşlemi ---
    QObject::connect(registerBtn, &QPushButton::clicked, [&]() {
        QString u = register_usernameInput->text();
        QString p = register_passwordInput->text();
        QString n = register_nameInput->text();
        QString phone = register_phoneInput->text();

        if (u.isEmpty() || p.isEmpty() || n.isEmpty() || phone.isEmpty()) {
            QMessageBox::warning(registerPage, "Hata", "Tüm alanlar boş bırakılamaz.");
            return;
        }

        if (findCustomerByUsername(u.toStdString()) || findEmployeeByUsername(u.toStdString())) {
            QMessageBox::warning(registerPage, "Hata", "Bu kullanıcı adı zaten sistemde mevcut.");
            return;
        }

        int id = QRandomGenerator::global()->generate() % 9000 + 1000;
        customers.push_back(new Customer(n.toStdString(), phone.toStdString(), id, u.toStdString(), p.toStdString()));
        QMessageBox::information(registerPage, "Başarılı", "Müşteri kaydı başarıyla oluşturuldu! Şimdi giriş yapabilirsiniz.");
        notificationSystem.sendNotification(u.toStdString(), "Sistemimize hoş geldiniz.");

        // Kayıt başarılı, giriş ekranına geri dön
        stackedWidget->setCurrentIndex(1);
    });

    // --- Giriş Yap İşlemi ---
    QObject::connect(loginBtn, &QPushButton::clicked, [&]() {
        string enteredUsername = login_usernameInput->text().toStdString();
        string enteredPassword = login_passwordInput->text().toStdString();

        // 1. Müşteri Kontrolü
        Customer* customer = findCustomerByUsername(enteredUsername);
        if (customer && customer->getPassword() == enteredPassword) {
            updateCustomerPanelTable(customerVehicleTable);
            stackedWidget->setCurrentIndex(4); // Customer Page
            return;
        }

        // 2. Çalışan Kontrolü
        Employee* employee = findEmployeeByUsername(enteredUsername);
        if (employee && employee->getPassword() == enteredPassword) {

            updateVehicleTable();
            updateCustomerTable();
            updateRentalTable();
            updatePaymentTable();
            updateMaintenanceTable();

            // Sekmeleri sıfırlama ve role göre ayarlama
            adminTabs->clear();
            adminTabs->addTab(rentalTab, "📝 Rentals");
            adminTabs->addTab(paymentsTab, "💳 Payments");

            if (employee->getRole() == "Manager") {
                adminTabs->insertTab(0, vehiclesTab, "🚗 Vehicles");
                adminTabs->insertTab(1, customersTab, "👤 Customers");
                adminTabs->addTab(maintenanceTab, "⚙ Maintenance");
                adminTabs->addTab(branchesTab, "🏢 Branches");
            } else if (employee->getRole() == "Sales") {
                // Sales (Satış) personeli sadece kiralama ve ödeme işlemlerini yönetir.
            }
            updateBranchTable();
            stackedWidget->setCurrentIndex(3); // Admin Page
            return;
        }

        QMessageBox::warning(loginPage, "Hata", "Geçersiz giriş bilgileri!");
    });


    // --- Kiralama İşlemi (Müşteri Paneli) ---
    QObject::connect(rentCarBtn, &QPushButton::clicked, [&]() {
        Customer* currentCustomer = findCustomerByUsername(login_usernameInput->text().toStdString());

        if (!currentCustomer) {
            QMessageBox::warning(customerPage, "Hata", "Giriş yapan müşteri bilgisi bulunamadı!");
            return;
        }

        int selectedRow = customerVehicleTable->currentRow();
        if (selectedRow == -1) {
            QMessageBox::warning(customerPage, "Hata", "Lütfen önce kiralamak istediğiniz aracı listeden seçin!");
            return;
        }

        // Seçim Parametrelerini Toplama (Plaka, 4. sütunda)
        QString plate = customerVehicleTable->item(selectedRow, 4)->text();
        int days = rentDaysInput->text().toInt();
        QString sDate = startDateEdit->date().toString("dd/MM/yyyy");

        if (days <= 0) {
            QMessageBox::warning(customerPage, "Hata", "Lütfen geçerli gün sayısı girin!");
            return;
        }

        Vehicle* selectedVehicle = findVehicle(plate.toStdString());

        // Sigortayı Bulma
        QString selectedInsuranceText = insuranceCombo->currentText();
        string insuranceName = selectedInsuranceText.split(" (").at(0).toStdString();
        Insurance* selectedInsurance = nullptr;
        for(Insurance* ins : insuranceOptions) {
            if (ins->getName() == insuranceName) {
                selectedInsurance = ins;
                break;
            }
        }

        if (!selectedVehicle || !selectedInsurance) {
            QMessageBox::critical(customerPage, "Hata", "Araç veya sigorta seçimi geçersiz.");
            return;
        }

        if (selectedVehicle->getStatus() != "Available") {
            QMessageBox::warning(customerPage, "Hata", "Seçilen araç şu anda kirada veya rezerve edilmiş durumda.");
            return;
        }


        // --- Maliyet Hesaplama ---
        double vehicleCost = selectedVehicle->calculatePrice(days);
        double insuranceCost = selectedInsurance->getDailyCost() * days;
        double totalPrice = vehicleCost + insuranceCost;

        // --- Rezervasyon Ücreti (%25) Hesaplama ---
        double depositRate = 0.25;
        double depositAmount = totalPrice * depositRate;

        // --- Onay Diyaloğu Oluşturma ---
        QDialog confirmationDialog(customerPage);
        confirmationDialog.setWindowTitle("Rezervasyon Ön Ödeme ve Onay");
        confirmationDialog.resize(500, 400); // Diyalog boyutunu ayarla
        QVBoxLayout *dialogLayout = new QVBoxLayout(&confirmationDialog);

        QString summary = QString("<h3>Rezervasyon Özeti</h3>") +
                          QString("<b>Müşteri:</b> %1<br>").arg(QString::fromStdString(currentCustomer->getName())) +
                          QString("<b>Araç:</b> %1 (%2)<br>").arg(QString::fromStdString(selectedVehicle->getModel()), QString::fromStdString(selectedVehicle->getPlate())) +
                          QString("<b>Kiralama Gün Sayısı:</b> %1 gün<br>").arg(days) +
                          QString("<b>Başlangıç Tarihi:</b> %1<br>").arg(sDate) +
                          QString("<b>Sigorta Tipi:</b> %1 (%2 TL/gün)<br><br>").arg(QString::fromStdString(selectedInsurance->getName()), QString::number(selectedInsurance->getDailyCost(), 'f', 2)) +
                          QString("<hr>") +
                          QString("<b>Toplam Kiralama Maliyeti:</b> %1 TL<br>").arg(QString::number(totalPrice, 'f', 2)) +
                          QString("<b>Ön Ödeme Oranı:</b> %25<br>") +
                          QString("<h3>Ödenmesi Gereken Rezervasyon Ücreti: %1 TL</h3>").arg(QString::number(depositAmount, 'f', 2));

        QLabel *summaryLabel = new QLabel(summary);
        summaryLabel->setTextFormat(Qt::RichText);
        dialogLayout->addWidget(summaryLabel);

        // Ödeme Metodu Seçimi
        QComboBox *paymentMethod = new QComboBox();
        paymentMethod->addItem("Nakit (Cash)");
        paymentMethod->addItem("Kredi Kartı (Credit Card)");
        paymentMethod->addItem("Online Transfer");
        dialogLayout->addWidget(new QLabel("Ödeme Metodunu Seçin:"));
        dialogLayout->addWidget(paymentMethod);

        // Butonlar
        QPushButton *confirmBtn = new QPushButton(QString("%1 TL Ödeyerek Rezervasyonu Onayla").arg(QString::number(depositAmount, 'f', 2)));
        QPushButton *cancelBtn = new QPushButton("İptal");
        confirmBtn->setStyleSheet("background-color: #FFA500; color: white;");

        QHBoxLayout *btnLayout = new QHBoxLayout();
        btnLayout->addWidget(confirmBtn);
        btnLayout->addWidget(cancelBtn);
        dialogLayout->addLayout(btnLayout);

        // --- Onay Butonu Bağlantısı (Rezervasyon ve Ön Ödeme İşlemini Gerçekleştirme) ---
        QObject::connect(confirmBtn, &QPushButton::clicked, [&, depositAmount, totalPrice, selectedVehicle, currentCustomer, selectedInsurance, days]() {
            // Kiralama Oluşturma (Status: Reserved)
            int newRentalId = rentals.empty() ? 1 : rentals.back()->id + 1;

            Rental* r = new Rental(newRentalId, currentCustomer, selectedVehicle, days, startDateEdit->date().toString("dd/MM/yyyy").toStdString(), selectedInsurance);
            r->status = "Reserved";

            rentals.push_back(r);

            // Ödeme Oluşturma
            string paymentMethodStr = paymentMethod->currentText().split(" (").at(0).toStdString();
            string currentDate = QDate::currentDate().toString("dd/MM/yyyy").toStdString();
            Payment* p = nullptr;

            if (paymentMethodStr == "Nakit") p = new CashPayment(depositAmount, currentDate, newRentalId); // DÜZELTİLDİ
            else if (paymentMethodStr == "Kredi Kartı") p = new CardPayment(depositAmount, currentDate, "****", newRentalId); // DÜZELTİLDİ

            else if (paymentMethodStr == "Online Transfer") p = new OnlinePayment(depositAmount, currentDate, newRentalId);

            if (p) {
                payments.push_back(p);

                // Araç durumunu "Reserved" olarak güncelle
                selectedVehicle->setStatus("Reserved");

                // Kalan bakiye hesaplaması
                double remainingAmount = totalPrice - depositAmount;

                // Tüm tabloları ve durumu güncelle
                updateCustomerPanelTable(customerVehicleTable);
                updateRentalTable();
                updateVehicleTable();
                updatePaymentTable();

                QMessageBox::information(customerPage, "Başarılı",
                                         QString("Rezervasyonunuz başarıyla oluşturuldu!\n") +
                                             QString("Ödenen Ön Ödeme: %1 TL\n").arg(QString::number(depositAmount, 'f', 2)) +
                                             QString("Kalan Bakiye: %1 TL (Kiralama başlangıcında ödenecektir.)").arg(QString::number(remainingAmount, 'f', 2))
                                         );

                notificationSystem.sendNotification(
                    currentCustomer->getUsername(),
                    (QString("Araç rezervasyonunuz başarıyla tamamlandı. Kalan ödeme: ") +
                     QString::number(remainingAmount, 'f', 2) +
                     QString(" TL."))
                        .toStdString()
                    );
                confirmationDialog.accept(); // Diyaloğu kapat
            } else {
                QMessageBox::critical(customerPage, "Hata", "Ödeme nesnesi oluşturulamadı.");
            }
        });
        // --- Kiralama Sonlandırma İşlemi (Admin Paneli) ---
        QObject::connect(rentalTable, &QTableWidget::cellClicked, [&](int row, int column) {
            // Sadece 'Actions' sütununa (6. sütun) tıklanırsa devam et
            if (column == 6) {
                // 1. Tıklanan hücredeki QWidget'i al
                QWidget *actionWidget = rentalTable->cellWidget(row, column);
                if (!actionWidget) return;

                // 2. QWidget içindeki butonu bul
                // QTableWidget::cellWidget, bir QWidget'i döndürür. Butonu bulmak için findChild kullanılır.
                QPushButton *endRentalBtn = actionWidget->findChild<QPushButton*>();
                if (!endRentalBtn) return;

                // 3. Butonun objectName'ini (Rental ID) al
                int rentalId = endRentalBtn->objectName().toInt();
                Rental* rental = findRentalById(rentalId);




                if (!rental) {
                    QMessageBox::warning(rentalTable, "Hata", "Kiralama kaydı bulunamadı.");
                    return;
                }

                if (rental->status != "Reserved" && rental->status != "Active") {
                    QMessageBox::information(rentalTable, "Bilgi", "Bu kiralama zaten sonlandırılmış veya iptal edilmiş.");
                    return;
                }

                // --- SONLANDIRMA ONAYI VE İŞLEMİ ---
                QMessageBox::StandardButton reply;
                reply = QMessageBox::question(rentalTable, "Kiralama Sonlandırma",
                                              QString("'%1' plakalı aracın kiralamasını sonlandırmak istediğinizden emin misiniz? Kalan ödeme tahsil edilecektir.")
                                                  .arg(QString::fromStdString(rental->vehicle->getPlate())),
                                              QMessageBox::Yes | QMessageBox::Cancel);

                if (reply == QMessageBox::Yes) {
                    // 1. Kalan Ödemeyi Hesapla
                    double totalPaid = 0.0;
                    // Normalde bu adımda, o kiralama ID'sine ait ödemeler toplanır. Basitlik için sadece depozitonun ödendiğini varsayalım (Toplam Fiyatın %25'i)
                    // Rezervasyon sırasında %25'in ödendiğini varsayarsak:
                    double depositRate = 0.25;
                    double remainingAmount = rental->price * (1.0 - depositRate);

                    // 2. Kalan Ödemeyi Tahsil Et (Yeni Ödeme Kaydı Oluştur)
                    QDialog paymentDialog(rentalTable);
                    paymentDialog.setWindowTitle("Kalan Ödeme Tahsili");
                    QVBoxLayout *pLayout = new QVBoxLayout(&paymentDialog);

                    QLabel *amountLabel = new QLabel(QString("Kalan Tutar: <b>%1 TL</b>").arg(QString::number(remainingAmount, 'f', 2)));
                    amountLabel->setTextFormat(Qt::RichText);
                    pLayout->addWidget(amountLabel);

                    QComboBox *paymentMethod = new QComboBox();
                    paymentMethod->addItem("Nakit (Cash)");
                    paymentMethod->addItem("Kredi Kartı (Credit Card)");
                    pLayout->addWidget(new QLabel("Ödeme Metodu:"));
                    pLayout->addWidget(paymentMethod);

                    QPushButton *completeBtn = new QPushButton("Ödemeyi Tamamla ve Kiralamayı Bitir");
                    pLayout->addWidget(completeBtn);

                    QObject::connect(completeBtn, &QPushButton::clicked, [&, rental, remainingAmount, &paymentDialog]() {
                        int currentRentalId = rental->id;

                        // Ödeme nesnesini oluştur
                        string method = paymentMethod->currentText().split(" (").at(0).toStdString();
                        string currentDate = QDate::currentDate().toString("dd/MM/yyyy").toStdString();
                        Payment* newPayment = nullptr;

                        // YENİ: Rental ID'sini yapıcıya geçiriyoruz (Bu, Payment sınıflarınızın güncellendiğini varsayar!)
                        if (method == "Nakit") newPayment = new CashPayment(remainingAmount, currentDate, currentRentalId);
                        else if (method == "Kredi Kartı") newPayment = new CardPayment(remainingAmount, currentDate, "****", currentRentalId);
                        else if (method == "Online Transfer") newPayment = new OnlinePayment(remainingAmount, currentDate, currentRentalId); // YENİ EKLEME
                        else {
                            // Online transfer seçeneği varsa onu da ekleyin, yoksa hata verdirin.
                            QMessageBox::critical(&paymentDialog, "Hata", "Geçersiz ödeme metodu.");
                            return;
                        }



                        if (newPayment) {
                            payments.push_back(newPayment);

                            // 3. Rental Kaydını Güncelle
                            rental->status = "Completed";
                            rental->endDate = QDate::currentDate().toString("dd/MM/yyyy").toStdString();

                            // 4. Aracın Durumunu Güncelle
                            rental->vehicle->setStatus("Available");

                            // Tabloları Güncelle
                            updateRentalTable();
                            updatePaymentTable();
                            updateVehicleTable();

                            notificationSystem.sendNotification(rental->customer->getUsername(),
                                                                QString("Sayın %1, %2 plakalı aracın kiralaması başarıyla sonlandırıldı. İade tarihi: %3")
                                                                    .arg(QString::fromStdString(rental->customer->getName()), QString::fromStdString(rental->vehicle->getPlate()), QString::fromStdString(rental->endDate))
                                                                    .toStdString());

                            QMessageBox::information(&paymentDialog, "Başarılı", "Kiralama başarıyla sonlandırıldı ve kalan ödeme tahsil edildi.");
                            paymentDialog.accept(); // Diyalogu kapat
                        } else {
                            QMessageBox::critical(&paymentDialog, "Hata", "Ödeme nesnesi oluşturulamadı.");
                        }
                    });

                    paymentDialog.exec();
                }
            }
        });


        QObject::connect(cancelBtn, &QPushButton::clicked, &confirmationDialog, &QDialog::reject);

        confirmationDialog.exec();
    });

    // --- Uygulamayı Başlatma ---
    stackedWidget->setCurrentIndex(0); // Başlangıçta Welcome ekranını göster
    mainWindow.show();
    return app.exec();
}
